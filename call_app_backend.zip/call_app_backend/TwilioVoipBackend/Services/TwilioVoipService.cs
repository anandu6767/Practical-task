﻿using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using Microsoft.Extensions.Options;
using System;
using TwilioVoipBackend.Models;

namespace TwilioVoipBackend.Services
{
    public class TwilioVoipService
    {
        private readonly TwilioSettings _twilioSettings;

        // Inject TwilioSettings using IOptions<TwilioSettings>
        public TwilioVoipService(IOptions<TwilioSettings> twilioSettings)
        {
            _twilioSettings = twilioSettings.Value;

            // Initialize Twilio client with values from TwilioSettings
            TwilioClient.Init(_twilioSettings.AccountSid, _twilioSettings.AuthToken);
        }

       
        /// <param name="toPhoneNumber">The destination phone number</param>
        
        public string MakeCall(string toPhoneNumber)
        {
            var to = new PhoneNumber(toPhoneNumber);
            var from = new PhoneNumber(_twilioSettings.PhoneNumber);

            // Initiate the call using the local TwiML URL
            var call = CallResource.Create(
                to: to,
                from: from,
                url: new Uri("https://localhost:7257/api/twilio/voice") // Custom TwiML URL for handling the call
            );

            return call.Sid;
        }

        /// <summary>
        /// Sends an SMS to the specified phone number (Optional for later).
        /// </summary>
        /// <param name="toPhoneNumber">The destination phone number</param>
        /// <param name="message">The message content</param>
        /// <returns>The SID of the sent message</returns>
        public string SendSms(string toPhoneNumber, string message)
        {
            var to = new PhoneNumber(toPhoneNumber);
            var from = new PhoneNumber(_twilioSettings.PhoneNumber);

            var sms = MessageResource.Create(
                to: to,
                from: from,
                body: message
            );

            return sms.Sid;
        }
    }
}
