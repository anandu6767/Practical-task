﻿using Microsoft.AspNetCore.Mvc;
using Twilio.TwiML;
using TwilioVoipBackend.Services;

namespace TwilioVoipBackend.Controllers
{
    public class CallController : Controller
    {
        private readonly TwilioVoipService _twilioVoipService;

        // Constructor injection for TwilioVoipService
        public CallController(TwilioVoipService twilioVoipService)
        {
            _twilioVoipService = twilioVoipService;
        }

        // Endpoint to handle incoming call requests from Twilio
        [HttpGet]
        [Route("api/twilio/voice")]
        public IActionResult HandleIncomingCall()
        {
            var response = new VoiceResponse();
            response.Say("Hello! This is a test call from Twilio.");
            response.Pause();
            response.Say("Goodbye!");

            return Content(response.ToString(), "application/xml");
        }

        [HttpPost]
        [Route("api/call/make")]
        public IActionResult MakeCall(string toPhoneNumber)
        {
            if (string.IsNullOrEmpty(toPhoneNumber))
            {
                return BadRequest("Phone number cannot be empty.");
            }

            try
            {
                var callSid = _twilioVoipService.MakeCall(toPhoneNumber);
                Console.WriteLine($"Call initiated with SID: {callSid}");
                return Ok(new { CallSid = callSid });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error initiating call: {ex.Message}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost]
        [Route("api/call/receive")] // Define a route for receiving calls
        public IActionResult ReceiveCall()
        {
            var response = new VoiceResponse();
            response.Say("You have an incoming call. Please leave a message after the beep.");
            response.Record(); // Optionally record the message
            response.Say("Goodbye!");

            return Content(response.ToString(), "application/xml");
        }
    }
}
