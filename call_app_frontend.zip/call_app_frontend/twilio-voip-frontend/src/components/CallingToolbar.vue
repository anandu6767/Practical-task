<template>
    <div class="calling-toolbar">
      <input v-model="phoneNumber" placeholder="Enter phone number" />
      <button @click="dialCall">Dial Call</button>
      <button @click="receiveCall">Receive Call</button> <!-- New button for receiving calls -->
      <button @click="muteCall">{{ muted ? 'Unmute' : 'Mute' }}</button>
      <button @click="pauseCall">{{ paused ? 'Continue' : 'Pause' }}</button>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  import { Device } from '@twilio/voice-sdk'; // Ensure this import is correct
  
  export default {
    data() {
      return {
        phoneNumber: '',
        muted: false,
        paused: false,
        activeCall: null, // Variable to hold the active call
      };
    },
    methods: {
      // Method to dial a call
      dialCall() {
        // Ensure that the phone number is provided before making the request
        if (!this.phoneNumber) {
          alert("Please enter a phone number.");
          return;
        }
  
        // Update the POST request URL to match the new route
        axios.post('https://localhost:44324/api/call/make', null, { params: { toPhoneNumber: this.phoneNumber } })
          .then(response => {
            if (response && response.data) {
              // Access the Call Object
              this.activeCall = response.data; // Assuming response.data contains the call object or SID
              console.log('Call started:', response.data);
              alert(`Call started successfully with SID: ${response.data.CallSid}`);
  
              // Assuming response.data contains a token for Twilio SDK
              this.initializeCall(response.data.token); // Initialize the call with the token
            } else {
              console.error('Unexpected response format:', response);
              alert('Call started, but unexpected response format.');
            }
          })
          .catch(error => {
            console.error('Error starting call:', error.response ? error.response.data : error.message);
            alert('An error occurred while trying to start the call.');
          });
      },
  
      // Method to simulate receiving a call
      receiveCall() {
        console.log("Simulating receiving a call...");
        alert("You have an incoming call!");
        // You might want to actually implement the logic to receive a call
      },
  
      // Method to initialize the Twilio call
      initializeCall(token) {
        Device.setup(token); // Setup the Twilio Device with the token
        Device.on('incoming', call => {
          console.log('Incoming call from:', call.parameters.From);
          this.activeCall = call;
          call.accept(); // Automatically accept the call for this example
        });
  
        // Handle the active call
        Device.on('callStarted', call => {
          console.log('Call is active:', call);
          this.activeCall = call; // Store the active call
        });
      },
  
      // Method to mute/unmute the call
      muteCall() {
        if (this.activeCall) {
          this.muted = !this.muted;
          if (this.muted) {
            this.activeCall.mute(); // Mute the call
            console.log('Call muted');
          } else {
            this.activeCall.unmute(); // Unmute the call
            console.log('Call unmuted');
          }
        } else {
          console.error('No active call to mute/unmute.');
        }
      },
  
      // Method to pause/resume the call
      pauseCall() {
        if (this.activeCall) {
          this.paused = !this.paused;
          if (this.paused) {
            this.activeCall.pause(); // Check if Twilio SDK supports this
            console.log('Call paused');
          } else {
            this.activeCall.resume(); // Check if Twilio SDK supports this
            console.log('Call continued');
          }
        } else {
          console.error('No active call to pause/resume.');
        }
      }
    }
  };
  </script>
  
  <style scoped>
  .calling-toolbar {
    display: flex;
    flex-direction: column;
    width: 200px;
    margin: auto;
  }
  button {
    margin: 10px 0;
  }
  </style>
  