<template>
  <div id="app">
    <CallingToolbar />
  </div>
</template>

<script>
import CallingToolbar from './components/CallingToolbar.vue';

export default {
  components: {
    CallingToolbar
  }
};
</script>
