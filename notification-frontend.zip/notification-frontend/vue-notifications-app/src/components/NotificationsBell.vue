<template>
  <nav class="navbar">
    <div class="navbar-content">
      <!-- Notifications bell icon with unread count badge -->
      <div class="notifications-bell" @click="toggleNotifications">
        <i class="fas fa-bell"></i>
        <!-- Display unreadCount badge only when unreadCount is greater than 0 -->
        <span v-if="unreadCount > 0" class="badge">{{ unreadCount }}</span>
      </div>
    </div>

    <!-- Display notifications list below the navbar -->
    <div v-if="showingNotifications" class="notifications-list">
      <p v-for="notification in notifications" :key="notification.id">{{ notification.message }}</p>
    </div>
  </nav>
</template>

<script>
import { HubConnectionBuilder } from "@microsoft/signalr";

export default {
  data() {
    return {
      notifications: [], // Store notifications
      unreadCount: 0,    // Unread notification count
      showingNotifications: false, // Toggle notification display
      connection: null, // SignalR connection
    };
  },
  
  created() {
    this.initializeSignalR(); // Initialize SignalR when component is created
    this.showNotifications(); // Fetch initial notifications
  },
  
  methods: {
    // Fetch notifications from the API
    async showNotifications() {
      try {
        const response = await fetch("https://localhost:7000/api/notifications");
        const data = await response.json();
        this.notifications = data.notifications;
        this.updateUnreadCount(this.notifications.length); // Update the unread count after fetching notifications
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      }
    },
    
    toggleNotifications() {
      this.showingNotifications = !this.showingNotifications;
      if (this.showingNotifications) {
        this.showNotifications(); // Fetch notifications when opened
      }
    },
    
    updateUnreadCount(count) {
      this.unreadCount = count; // Update the unread notification count
    },
    
    addNotification(message) {
      this.notifications.push({ id: Date.now(), message: message }); // Add a new notification
      this.updateUnreadCount(this.notifications.length); // Update unread count
    },

    initializeSignalR() {
      this.connection = new HubConnectionBuilder()
        .withUrl("https://localhost:7000/notificationsHub") // Ensure this matches your hub URL
        .build();

      this.connection.start()
        .then(() => console.log("SignalR Connected"))
        .catch(err => console.error("SignalR Connection Error: ", err));

      // Listen for new notifications
      this.connection.on("ReceiveNotification", (message) => {
        this.addNotification(message); // Add new notification
      });
    },
  }
};
</script>

<style scoped>
/* General navbar styling */
.navbar {
  background-color: #2c3e50;
  padding: 10px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 5;
}

.navbar-content {
  display: flex;
  align-items: center;
  width: 100%;
  justify-content: flex-end; /* Align bell icon to the right */
}

/* Notifications bell styling */
.notifications-bell {
  position: relative;
  cursor: pointer;
  font-size: 24px;
  color: #ecf0f1;
}

.notifications-bell:hover {
  color: #f39c12;
}

/* Unread notification count */
.badge {
  background-color: red;
  color: white;
  border-radius: 50%;
  padding: 3px 8px;
  position: absolute;
  top: -10px; /* Adjust as necessary */
  right: -10px; /* Adjust as necessary */
  font-size: 12px;
  font-weight: bold;
  display: inline-block; /* Ensure it's displayed as an inline block */
}

/* Notifications dropdown styling */
.notifications-list {
  background-color: #fff;
  color: #2c3e50;
  position: absolute;
  top: 100%; /* Display the notification list directly below the navbar */
  right: 20px;
  width: 250px;
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  z-index: 10;
}

.notifications-list p {
  margin: 5px 0;
  font-size: 14px;
  color: #2c3e50;
}

.notifications-list p:hover {
  background-color: #ecf0f1;
  padding: 5px;
  border-radius: 3px;
}
</style>
