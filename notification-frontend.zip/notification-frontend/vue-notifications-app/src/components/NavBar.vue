<template>
    <nav class="navbar">
      <div class="logo">Notification-App</div>
      <notifications-bell :unread-count="unreadCount" />
    </nav>
  </template>
  
  <script>
  import NotificationsBell from './NotificationsBell.vue';
  
  export default {
    components: {
      NotificationsBell,
    },
    data() {
      return {
        unreadCount: 0,
      };
    },
    methods: {
      // Method to update unread notifications count
      updateUnreadCount(count) {
        this.unreadCount = count;
      },
    },
  };
  </script>
  
  <style scoped>
.navbar {
  display: flex;
  justify-content: space-between;
  padding: 10px 20px; 
  background-color: #4a90e2; 
  color: #ffffff; 
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2); 
}

.logo {
  font-size: 36px; 
  font-weight: bold;
  letter-spacing: 1px; 
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 1); 
}


.notifications-bell {
  cursor: pointer; 
  display: flex; 
  align-items: center;
  position: relative; 
}
</style>
  