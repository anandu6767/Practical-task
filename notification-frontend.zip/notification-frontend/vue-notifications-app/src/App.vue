<template>
  <div id="app">
    <NavBar ref="navbar" />
  </div>
</template>

<script>
import NavBar from './components/NavBar.vue';
import * as signalR from "@microsoft/signalr";
import '@fortawesome/fontawesome-free/css/all.css';

export default {
  components: {
    NavBar,
  },
  mounted() {
    this.startSignalRConnection();
  },
  methods: {
    async startSignalRConnection() {
      const connection = new signalR.HubConnectionBuilder()
        .withUrl("https://localhost:7000/notificationsHub")
        .withAutomaticReconnect()
        .build();

      // Listen for custom notification messages
      connection.on("ReceiveNotification", (message) => {
        console.log("Notification received: ", message);
        this.$refs.navbar.updateUnreadCount(this.$refs.navbar.unreadCount + 1);
        this.$refs.navbar.addNotification(message);
      });

      // Start the connection
      try {
        await connection.start();
        console.log("SignalR connected");
      } catch (err) {
        console.error("SignalR Connection Error: ", err);
      }

      // Handle connection close
      connection.onclose(async () => {
        console.log("Connection closed. Attempting to reconnect...");
        await this.startSignalRConnection();
      });
    }
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
