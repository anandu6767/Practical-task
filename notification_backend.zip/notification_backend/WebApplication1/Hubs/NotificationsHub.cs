﻿
using Microsoft.AspNetCore.SignalR;

namespace WebApplication1.Hubs
{
    public class NotificationsHub : Hub
    {
        public async Task SendNotification(int unreadCount)
        {
            await Clients.All.SendAsync("ReceiveNotification", unreadCount);
        }
    }
}