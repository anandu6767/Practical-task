﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using WebApplication1.Hubs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NotificationsApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationsController : ControllerBase
    {
        private readonly IHubContext<NotificationsHub> _hubContext;
        private static int _notificationCount = 0;
        private static List<object> _notifications = new List<object>(); // List to store notifications

        public NotificationsController(IHubContext<NotificationsHub> hubContext)
        {
            _hubContext = hubContext;
        }

        // Accepts a custom message in the POST request body
        [HttpPost]
        public async Task<IActionResult> PostNotification([FromBody] NotificationDto notificationDto)
        {
            _notificationCount++; // Increment the count

            // Create a new notification with the custom message
            var newNotification = new
            {
                Id = _notificationCount,
                Message = notificationDto.Message ?? $"Notification {_notificationCount}" // Default if message is null
            };

            // Add the notification to the list
            _notifications.Add(newNotification);

            // Send notification with custom message to SignalR clients
            await _hubContext.Clients.All.SendAsync("ReceiveNotification", newNotification.Message);

            return Ok(new { Message = "Notification sent successfully", Count = _notificationCount });
        }

        // DTO to accept message
        public class NotificationDto
        {
            public string Message { get; set; }
        }

        // Return list of notifications
        [HttpGet]
        public IActionResult GetNotifications()
        {
            return Ok(new { Notifications = _notifications });
        }

        
    }
}
